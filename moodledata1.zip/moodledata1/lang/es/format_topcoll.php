<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'format_topcoll', language 'es', branch 'MOODLE_26_STABLE'
 *
 * @package   format_topcoll
 * @copyright 1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['arrow'] = 'Flecha';
$string['bulb'] = 'Bombilla';
$string['center'] = 'Centro';
$string['cloud'] = 'Nube';
$string['colourrule'] = 'Por favor, introduzca un color RGB válido. Seis dígitos hexadecimales.';
$string['columnhorizontal'] = 'Horizontal';
$string['columnvertical'] = 'Vertical';
$string['ctreset'] = 'Resetear opciones de Collapsed Topics';
$string['ctreset_help'] = 'Establecer valorespor defecto a Collapsed Topics.';
$string['currentsection'] = 'Esta sección';
$string['defaultcoursedisplay_desc'] = 'O bien muestra todas las secciones o bien la sección cero y la seleccionada en la página.';
$string['defaultdisplayinstructions'] = 'Mostrar instrucciones a los usuarios';
$string['defaultdisplayinstructions_desc'] = 'Mostrar las instrucciones a los usuarios informándoles de cómo utilizar las conmutaciones. Puede ser sí o no.';
$string['defaultlayoutcolumnorientation_desc'] = 'Orientación por defecto de las columnas: Vertical u Horizontal.';
$string['defaultlayoutcolumns_desc'] = 'Número de columnas entre una y cuatro-';
$string['defaulttgbgcolour_desc'] = 'Color de fondo del conmutador en formato hexidecimal RGB.';
$string['defaulttgbghvrcolour_desc'] = 'Color de fondo flotante del conmutador en formato hexidecimal RGB.';
$string['defaulttgfgcolour_desc'] = 'Color de primer plano del conmutador en formato hexidecimal RGB.';
$string['defaulttogglealignment_desc'] = '\'Izquierda\', \'Centro\' o \'Derecha\'.';
$string['defaulttoggleallhover_desc'] = '\'No\' o \'Sí\'.';
$string['defaulttoggleiconposition'] = 'Posición del icono';
$string['defaulttoggleiconposition_desc'] = 'Establece si el icono debe estar de la izquierda o la derecha del texto de la conmutación.';
$string['defaulttogglepersistence'] = 'Persistencia del conmutador';
$string['displayinstructions'] = 'Mostrar instrucciones';
$string['displayinstructions_help'] = 'Establece si las instrucciones se deben mostrar al usuario o no.';
$string['eye'] = 'Ojo';
$string['formatsettings'] = 'Restablecer ajustes de formato';
$string['formatsettingsinformation'] = '<br />Para restablecer la configuración del formato de curso a los valores predeterminados, haga clic en el icono a la derecha.';
$string['formattopcoll'] = 'Temas colapsados';
$string['four'] = 'Cuatro';
$string['hidefromothers'] = 'Ocultar sección';
$string['instructions'] = 'Instrucciones: Hacer clic en el nombre de la sección muestra/oculta la sección.';
$string['left'] = 'Izquierda';
$string['maincoursepage'] = 'Página principal del curso';
$string['nametopcoll'] = 'Temas colapsados';
$string['numbersections'] = 'Numero de secciones';
$string['off'] = 'Off';
$string['on'] = 'On';
$string['one'] = 'Uno';
$string['page-course-view-topcoll'] = 'Cualquier página principal del curso en el formato de los temas colapsados';
$string['page-course-view-topcoll-x'] = 'Cualquier página del curso en el formato de los temas colapsados';
$string['pluginname'] = 'Temas colapsados';
$string['point'] = 'Punto';
$string['power'] = 'Polaridad';
$string['radio'] = 'Radio';
$string['resetallcolour'] = 'Colores';
$string['resetalldisplayinstructions'] = 'Mostrar instrucciones';
$string['resetalldisplayinstructions_help'] = 'Restablece las instrucciones de visualización al valor predeterminado para todos los cursos por lo que será como un curso la primera vez, que está en el formato de Temas Colapsados.';
$string['resetallgrp'] = 'Restablecer todo:';
$string['resetalllayout'] = 'Disposiciones de pantalla';
$string['resetalltogglealignment'] = 'Intercambiar alineaciones';
$string['resetalltoggleiconset'] = 'Intercambiar conjunto de iconos';
$string['resetcolour'] = 'Color';
$string['resetdisplayinstructions'] = 'Mostrar instrucciones';
$string['resetdisplayinstructions_help'] = 'Restablece las instrucciones de visualización al valor predeterminado por lo que será el mismo que un curso de primera vez que está en el formato de Temas colapsado.';
$string['resetgrp'] = 'Restablecer:';
$string['resetlayout'] = 'Disposición de pantalla';
$string['resettogglealignment'] = 'Intercambiar alineaciones';
$string['resettoggleiconset'] = 'Intercambiar conjunto de iconos';
$string['right'] = 'Derecha';
$string['section0name'] = 'General';
$string['sectionname'] = 'Sección';
$string['setcolour_help'] = 'Contiene la configuración que se puede hacer con el color del formato dentro del curso.';
$string['setlayout'] = 'Establecer disposición';
$string['setlayout_all'] = 'Palabra conmutada, \'Tema x\' / \'Semana x\' / \'Día x\' y número de sección';
$string['setlayoutcolumns_help'] = 'Cuantas columnas va a usar';
$string['setlayout_default'] = 'Defecto';
$string['setlayoutelements_help'] = 'La cantidad de información sobre las conmutaciones/secciones desea que se muestre.';
$string['setlayout_help'] = 'Contiene la configuración que se puede hacer con el diseño del formato del curso.';
$string['setlayout_no_additions'] = 'Sin adicionales';
$string['setlayout_no_section_no'] = 'Sin número de sección';
$string['setlayout_no_toggle_section_x'] = 'Sección no conmutable x';
$string['setlayout_no_toggle_section_x_section_no'] = 'Sección no conmutable x y número de sección';
$string['setlayout_no_toggle_word'] = 'Sin la palabra intercambiar';
$string['setlayout_no_toggle_word_toggle_section_x'] = 'Sin la palabra conmutar y sección conmutable x';
$string['setlayout_no_toggle_word_toggle_section_x_section_no'] = 'Sin palabra conmutar, sección conmutable x y número de sección';
$string['setlayout_section_number'] = 'Número de seccion';
$string['setlayoutstructureday'] = 'Día';
$string['setlayoutstructuretopic'] = 'Tema';
$string['setlayoutstructureweek'] = 'Semana';
$string['setlayout_toggle_section_x'] = '\'Tema x\' / \'Semana x\' / \'Día x\'';
$string['setlayout_toggle_section_x_section_number'] = '\'Tema x\' / \'Semana x\' / \'Día x\' y número de sección';
$string['setlayout_toggle_word'] = 'Palabra conmutar';
$string['setlayout_toggle_word_section_number'] = 'Palabra conmutar y número de sección';
$string['setlayout_toggle_word_section_x'] = 'Palabra conmutar y \'Tema x\' / \'Semana x\' / \'Día x\'';
$string['settogglealignment_help'] = 'Establece la alineación del texto en el conmutador.';
$string['settoggleallhover_help'] = 'Establece si el conmutador de todos los iconos cambiarán cuando se mueve el ratón sobre ellas.';
$string['settogglebackgroundcolour'] = 'Fondo del conmutador';
$string['settogglebackgroundcolour_help'] = 'Establece el color de fondo de la conmutación.';
$string['settogglebackgroundhovercolour'] = 'Flotante Fondo';
$string['settogglebackgroundhovercolour_help'] = 'Establece el color de fondo de la conmutación cuando el ratón se mueve sobre él.';
$string['settoggleforegroundcolour'] = 'Primer Plano';
$string['settoggleforegroundcolour_help'] = 'Establece el color del texto en el conmutador.';
$string['settoggleiconposition_help'] = 'Establece que el icono debe estar de la izquierda o la derecha del texto de la conmutación.';
$string['settoggleiconset_help'] = 'Establece el ícono del conmutador.';
$string['showfromothers'] = 'Mostrar sección';
$string['smiley'] = 'Sonriente';
$string['square'] = 'Cuadrado';
$string['sunmoon'] = 'Sol / Luna';
$string['switch'] = 'Interruptor';
$string['three'] = 'Tres';
$string['topcollall'] = 'secciones.';
$string['topcoll:changecolour'] = 'Cambiar o restablecer el color';
$string['topcoll:changelayout'] = 'Cambiar o restablecer el diseño del conmutador';
$string['topcoll:changetogglealignment'] = 'Cambiar o restablecer la alineación del conmutador';
$string['topcoll:changetoggleiconset'] = 'Cambiar o restablecer el ícono del conmutador';
$string['topcollclosed'] = 'Cerrar todo';
$string['topcollopened'] = 'Abrir todo';
$string['topcolltoggle'] = 'Cambiar';
$string['two'] = 'Dos';
