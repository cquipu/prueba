<?php

function xmldb_auth_cas_install() {
    global $CFG, $DB;

}
