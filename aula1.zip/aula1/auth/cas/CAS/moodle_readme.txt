Description of phpCAS 1.3.3 library import

* downloaded from http://downloads.jasig.org/cas-clients/php/current/

merrill
