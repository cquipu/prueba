<?php

$string['pluginname'] = 'Foo!';
